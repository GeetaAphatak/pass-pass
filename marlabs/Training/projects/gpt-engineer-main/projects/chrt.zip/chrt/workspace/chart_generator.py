import matplotlib.pyplot as plt
import seaborn as sns

class ChartGenerator:
    def __init__(self, data):
        self.data = data

    def generate_chart(self, chart_type):
        # Generate the appropriate chart based on the chart_type
        # This is a placeholder. The actual implementation will depend on the specific requirements of the data and the chart_type.
        if chart_type == 'bar':
            sns.barplot(data=self.data)
        elif chart_type == 'line':
            sns.lineplot(data=self.data)
        elif chart_type == 'pie':
            self.data.plot(kind='pie')
        plt.show()
