from streamlit_app import StreamlitApp

if __name__ == "__main__":
    app = StreamlitApp("path_to_csv_file.csv")
    app.run()
